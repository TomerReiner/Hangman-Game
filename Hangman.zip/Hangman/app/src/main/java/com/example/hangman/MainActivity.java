package com.example.hangman;

/**
 * Hangman game
 * @by: Tomer Reiner
 */


import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Arrays;

public class MainActivity extends AppCompatActivity {

    private final String[] WORDS = TextHandler.toArray(); // Get the List of Words.
    private final int INDEX_OF_WORD = (int) (Math.random() * WORDS.length); // Random index of words the WORDS array.
    final String SECRET_WORD = WORDS[INDEX_OF_WORD].toLowerCase(); // The secret words.
    private int numOfTries = 9; // Number of guesses.
    private String usedLetters = ""; // This String stores the used letter.
    private String secretWordHidden;

    private EditText etLetter;
    private Button btnGo;
    private TextView tvSecretWord;
    private ImageView imgHangmanMode;
    private TextView tvLettersUsed;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etLetter = findViewById(R.id.etLetter);
        btnGo = findViewById(R.id.btnGO);
        tvSecretWord = findViewById(R.id.tvSecretWord);
        imgHangmanMode = findViewById(R.id.imgHangmanMode);
        tvLettersUsed = findViewById(R.id.tvLettersUsed);

        secretWordHidden = buildSecretWord(SECRET_WORD);

        tvSecretWord.setText(secretWordHidden);
    }


    /**
     * @param secretWord The secret word
     * @return String with _ and spaces
     * @example buildSecretWord("hello"):
     * _ _ _ _ _
     */
    public String buildSecretWord (String secretWord){
        String secret = "";
        for (int i = 0; i < secretWord.length(); i++)
                secret += "_ ";
        return secret;
    }


    /**
     * This function checks if the input is valid(valid input: String with one letter).
     * @param input The input string.
     * @return true if the input is valid, false if not.
     */
    public boolean checkValidInput(String input){
        String inputToCheck = input.toLowerCase();
        if (inputToCheck.length() > 1 || input.equals(""))
            return false;
         // Check if the input is a letter.
         return inputToCheck.charAt(0) >= 'a' && inputToCheck.charAt(0) <= 'z' && !usedLetters.contains(input); // Check if the letter wasn't used yet and if the input is a letter.
    }


    /**
     * This function checks numOfTries, and changes the mode of the hangman.
     */
    public void changeHangmanMode() {
        switch (numOfTries) {
            case 0:
                imgHangmanMode.setImageResource(R.drawable.hangman9);
                Toast.makeText(MainActivity.this, String.format("You have lost. the secret words was: %s", SECRET_WORD), Toast.LENGTH_SHORT).show();
                btnGo.setClickable(false);
                return;
            case 1:
                Toast.makeText(MainActivity.this, String.format("You have %d tries left.", numOfTries), Toast.LENGTH_SHORT).show();
                imgHangmanMode.setImageResource(R.drawable.hangman8);
                return;
            case 2:
                Toast.makeText(MainActivity.this, String.format("You have %d tries left.", numOfTries), Toast.LENGTH_SHORT).show();
                imgHangmanMode.setImageResource(R.drawable.hangman7);
                return;
            case 3:
                Toast.makeText(MainActivity.this, String.format("You have %d tries left.", numOfTries), Toast.LENGTH_SHORT).show();
                imgHangmanMode.setImageResource(R.drawable.hangman6);
                return;
            case 4:
                Toast.makeText(MainActivity.this, String.format("You have %d tries left.", numOfTries), Toast.LENGTH_SHORT).show();
                imgHangmanMode.setImageResource(R.drawable.hangman5);
                return;
            case 5:
                Toast.makeText(MainActivity.this, String.format("You have %d tries left.", numOfTries), Toast.LENGTH_SHORT).show();
                imgHangmanMode.setImageResource(R.drawable.hangman4);
                return;
            case 6:
                Toast.makeText(MainActivity.this, String.format("You have %d tries left.", numOfTries), Toast.LENGTH_SHORT).show();
                imgHangmanMode.setImageResource(R.drawable.hangman3);
                return;
            case 7:
                Toast.makeText(MainActivity.this, String.format("You have %d tries left.", numOfTries), Toast.LENGTH_SHORT).show();
                imgHangmanMode.setImageResource(R.drawable.hangman2);
                return;
            case 8:
                Toast.makeText(MainActivity.this, String.format("You have %d tries left.", numOfTries), Toast.LENGTH_SHORT).show();
                imgHangmanMode.setImageResource(R.drawable.hangman1);
                return;
        }
    }

    /**
     * This replaces _ with letters
     * @param c the char to replace
     */
    public void replaceCharacters(char c) {
        char[] arr = secretWordHidden.toCharArray();
        for (int i = 0; i < SECRET_WORD.length(); i++) {
            if (SECRET_WORD.charAt(i) == c) // If the character in ith position equals c then we need to replace the _ in arr[i * 2] with c.
                arr[i * 2] = c;
        }
        secretWordHidden = new String(arr); // Updating secretWordHidden.
        tvSecretWord.setText(secretWordHidden); // Updating text.
    }

    /**
     * This function checks if the user won.
     * @return true if the user won, false if not.
     */
    public boolean checkForWin() {
        return secretWordHidden.indexOf('_') == -1;
    }


    /**
     * This function manages the game
     * @param view
     */
    public void go(View view) {
        String input = etLetter.getText().toString(); // Input from the edit text.
        if (input == null) // Protect ourselves from NullPointerException.
            input = "";
        if (!checkValidInput(input)) {
            Toast.makeText(this, "Valid input is one letter and can't be a letter that was guessed", Toast.LENGTH_SHORT).show();
            etLetter.setText("");
            return;
        }

        etLetter.setText(""); // Emptying the edit text

        if (!SECRET_WORD.contains(input) && checkValidInput(input)) { // If the letter is not in the secret word.
            numOfTries--;
            usedLetters += input + ", "; // Add the wrong letter to used letters.
            tvLettersUsed.setText(usedLetters);
            changeHangmanMode(); // Change the picture of the hangman.
        }
        else
            replaceCharacters(input.charAt(0));

        if (checkForWin()) { // If the player won
            Toast.makeText(this, "You won!!!", Toast.LENGTH_LONG).show();
            btnGo.setClickable(false);
        }

    }
}