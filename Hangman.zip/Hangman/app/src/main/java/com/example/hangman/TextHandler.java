package com.example.hangman;

public class TextHandler {

    public static String[] toArray(){
        String text = String.format("a\nability\nable\nabout\nabove\naccept\naccording\naccount\nacross\nact\naction\nactivity\nactually\nadd\naddress\n" +
                "administration\nadmit\nadult\naffect\nafter\nagain\nagainst\nage\nagency\nagent\nago\nagree\nagreement\nahead\nair\nall\nallow\nalmost\n" +
                "alone\nalong\nalready\nalso\nalthough\nalways\nAmerican\namong\namount\nanalysis\nand\nanimal\nanother\nanswer\nany\nanyone\nanything\nappear\n" +
                "apply\napproach\narea\nargue\narm\naround\narrive\nart\narticle\nartist\nas\nask\nassume\nat\nattack\nattention\nattorney\naudience\nauthor\n" +
                "authority\navailable\navoid\naway\nbaby\nback\nbad\nbag\nball\nbank\nbar\nbase\nbe\nbeat\nbeautiful\nbecause\nbecome\nbed\nbefore\nbegin\n" +
                "behavior\nbehind\nbelieve\nbenefit\nbest\nbetter\nbetween\nbeyond\nbig\nbill\nbillion\nbit\nblack\nblood\nblue\nboard\nbody\nbook\nborn\nboth\n" +
                "box\nboy\nbreak\nbring\nbrother\nbudget\nbuild\nbuilding\nbusiness\nbut\nbuy\nby\ncall\ncamera\ncampaign\ncan\ncancer\ncandidate\ncapital\ncar\ncard\ncare\n" +
                "career\ncarry\ncase\ncatch\ncause\ncell\ncenter\ncentral\ncentury\ncertain\ncertainly\nchair\nchallenge\nchance\nchange\ncharacter\ncharge\ncheck\nchild\nchoice\n" +
                "choose\nchurch\ncitizen\ncity\ncivil\nclaim\nclass\nclear\nclearly\nclose\ncoach\ncold\ncollection\ncollege\ncolor\ncome\ncommercial\ncommon\ncommunity\ncompany\ncompare\n" +
                "computer\nconcern\ncondition\nconference\nCongress\nconsider\nconsumer\ncontain\ncontinue\ncontrol\ncost\ncould\ncountry\ncouple\ncourse\ncourt\ncover\ncreate\ncrime\ncultural\n" +
                "culture\ncup\ncurrent\ncustomer\ncut\ndark\ndata\ndaughter\nday\ndead\ndeal\ndeath\ndebate\ndecade\ndecide\ndecision\ndeep\ndefense\ndegree\nDemocrat\ndemocratic\ndescribe\ndesign\n" +
                "despite\ndetail\ndetermine\ndevelop\ndevelopment\ndie\ndifference\ndifferent\ndifficult\ndinner\ndirection\ndirector\ndiscover\ndiscuss\ndiscussion\ndisease\ndo\ndoctor\ndog\ndoor\ndown\n" +
                "draw\ndream\ndrive\ndrop\ndrug\nduring\neach\nearly\neast\neasy\neat\neconomic\neconomy\nedge\neducation\neffect\neffort\neight\neither\nelection\nelse\nemployee\nend\nenergy\nenjoy\n" +
                "enough\nenter\nentire\nenvironment\nenvironmental\nespecially\nestablish\neven\nevening\nevent\never\nevery\neverybody\neveryone\neverything\nevidence\nexactly\nexample\nexecutive\n" +
                "exist\nexpect\nexperience\nexpert\nexplain\neye\nface\nfact\nfactor\nfail\nfall\nfamily\nfar\nfast\nfather\nfear\nfederal\nfeel\nfeeling\nfew\nfield\nfight\nfigure\nfill\nfilm\n" +
                "final\nfinally\nfinancial\nfind\nfine\nfinger\nfinish\nfire\nfirm\nfirst\nfish\nfive\nfloor\nfly\nfocus\nfollow\nfood\nfoot\nfor\nforce\nforeign\nforget\nform\nformer\nforward\n" +
                "four\nfree\nfriend\nfrom\nfront\nfull\nfund\nfuture\ngame\ngarden\ngas\ngeneral\ngeneration\nget\ngirl\ngive\nglass\ngo\ngoal\ngood\ngovernment\ngreat\ngreen\nground\ngroup\ngrow\n" +
                "growth\nguess\ngun\nguy\nhair\nhalf\nhand\nhang\nhappen\nhappy\nhard\nhave\nhe\nhead\nhealth\nhear\nheart\nheat\nheavy\nhelp\nher\nhere\nherself\nhigh\nhim\nhimself\nhis\nhistory\nhit\n" +
                "hold\nhome\nhope\nhospital\nhot\nhotel\nhour\nhouse\nhow\nhowever\nhuge\nhuman\nhundred\nhusband\nI\nidea\nidentify\nif\nimage\nimagine\nimpact\nimportant\nimprove\nin\ninclude\nincluding\n" +
                "increase\nindeed\nindicate\nindividual\nindustry\ninformation\ninside\ninstead\ninstitution\ninterest\ninteresting\ninternational\ninterview\ninto\ninvestment\ninvolve\nissue\nit\nitem\nits\n" +
                "itself\njob\njoin\njust\nkeep\nkey\nkid\nkill\nkind\nkitchen\nknow\nknowledge\nland\nlanguage\nlarge\nlast\nlate\nlater\nlaugh\nlaw\nlawyer\nlay\nlead\nleader\nlearn\nleast\nleave\nleft\nleg\n" +
                "legal\nless\nlet\nletter\nlevel\nlie\nlife\nlight\nlike\nlikely\nline\nlist\nlisten\nlittle\nlive\nlocal\nlong\nlook\nlose\nloss\nlot\nlove\nlow\nmachine\nmagazine\nmain\nmaintain\nmajor\n" +
                "majority\nmake\nman\nmanage\nmanagement\nmanager\nmany\nmarket\nmarriage\nmaterial\nmatter\nmay\nmaybe\nme\nmean\nmeasure\nmedia\nmedical\nmeet\nmeeting\nmember\nmemory\nmention\nmessage\n" +
                "method\nmiddle\nmight\nmilitary\nmillion\nmind\nminute\nmiss\nmission\nmodel\nmodern\nmoment\nmoney\nmonth\nmore\nmorning\nmost\nmother\nmouth\nmove\nmovement\nmovie\nMr\nMrs\nmuch\nmusic\nm" +
                "ust\nmy\nmyself\nname\nnation\nnational\nnatural\nnature\nnear\nnearly\nnecessary\nneed\nnetwork\nnever\nnew\nnews\nnewspaper\nnext\nnice\nnight\nno\nnone\nnor\nnorth\nnot\nnote\nnothing\nnotice\nnow\nn't\nnumber\noccur\nof\noff\noffer\noffice\nofficer\n" +
                "official\noften\noh\noil\nok\nold\non\nonce\none\nonly\nonto\nopen\noperation\nopportunity\noption\nor\norder\norganization\nother\nothers\nour\nout\noutside\nover\nown\nowner\n" +
                "page\npain\npainting\npaper\nparent\npart\nparticipant\nparticular\nparticularly\npartner\nparty\npass\npast\npatient\npattern\npay\npeace\npeople\nper\nperform\nperformance\nperhaps\nperiod\nperson\npersonal\n" +
                "phone\nphysical\npick\npicture\npiece\nplace\nplan\nplant\nplay\nplayer\nPM\npoint\npolice\npolicy\npolitical\npolitics\npoor\npopular\npopulation\nposition\npositive\npossible\npower\n" +
                "practice\nprepare\npresent\npresident\npressure\npretty\nprevent\nprice\nprivate\nprobably\nproblem\nprocess\nproduce\nproduct\nproduction\nprofessional\nprofessor\nprogram\nproject\nproperty\n" +
                "protect\nprove\nprovide\npublic\npull\npurpose\npush\nput\nquality\nquestion\nquickly\nquite\nrace\nradio\nraise\nrange\nrate\nrather\nreach\nread\nready\nreal\nreality\nrealize\nreally\nreason\n" +
                "receive\nrecent\nrecently\nrecognize\nrecord\nred\nreduce\nreflect\nregion\nrelate\nrelationship\nreligious\nremain\nremember\nremove\nreport\nrepresent\nRepublican\nrequire\nresearch\nresource\n" +
                "respond\nresponse\nresponsibility\nrest\nresult\nreturn\nreveal\nrich\nright\nrise\nrisk\nroad\nrock\nrole\nroom\nrule\nrun\nsafe\nsame\nsave\nsay\nscene\nschool\nscience\nscientist\nscore\nsea\n" +
                "season\nseat\nsecond\nsection\nsecurity\nsee\nseek\nseem\nsell\nsend\nsenior\nsense\nseries\nserious\nserve\nservice\nset\nseven\nseveral\nsex\nsexual\nshake\nshare\nshe\nshoot\nshort\nshot\n" +
                "should\nshoulder\nshow\nside\nsign\nsignificant\nsimilar\nsimple\nsimply\nsince\nsing\nsingle\nsister\nsit\nsite\nsituation\nsix\nsize\nskill\nskin\nsmall\nsmile\nso\nsocial\nsociety\nsoldier\n" +
                "some\nsomebody\nsomeone\nsomething\nsometimes\nson\nsong\nsoon\nsort\nsound\nsource\nsouth\nsouthern\nspace\nspeak\nspecial\nspecific\nspeech\nspend\nsport\nspring\nstaff\nstage\nstand\nstandard\n" +
                "star\nstart\nstate\nstatement\nstation\nstay\nstep\nstill\nstock\nstop\nstore\nstory\nstrategy\nstreet\nstrong\nstructure\nstudent\nstudy\nstuff\nstyle\nsubject\nsuccess\nsuccessful\nsuch\nsuddenly\n" +
                "suffer\nsuggest\nsummer\nsupport\nsure\nsurface\nsystem\ntable\ntake\ntalk\ntask\ntax\nteach\nteacher\nteam\ntechnology\ntelevision\ntell\nten\ntend\nterm\ntest\nthan\nthank\nthat\nthe\ntheir\nthem\n" +
                "themselves\nthen\ntheory\nthere\nthese\nthey\nthing\nthink\nthird\nthis\nthose\nthough\nthought\nthousand\nthreat\nthree\nthrough\nthroughout\nthrow\nthus\ntime\nto\ntoday\ntogether\ntonight\ntoo\ntop\n" +
                "total\ntough\ntoward\ntown\ntrade\ntraditional\ntraining\ntravel\ntreat\ntreatment\ntree\ntrial\ntrip\ntrouble\ntrue\ntruth\ntry\nturn\nTV\ntwo\ntype\nunder\nunderstand\nunit\nuntil\nup\nupon\nus\nuse\n" +
                "usually\nvalue\nvarious\nvery\nvictim\nview\nviolence\nvisit\nvoice\nvote\nwait\nwalk\nwall\nwant\nwar\nwatch\nwater\nway\nwe\nweapon\nwear\nweek\nweight\nwell\nwest\nwestern\nwhat\nwhatever\nwhen\n" +
                "where\nwhether\nwhich\nwhile\nwhite\nwho\nwhole\nwhom\nwhose\nwhy\nwide\nwife\nwill\nwin\nwind\nwindow\nwish\nwith\n" +
                "within\nwithout\nwoman\nwonder\nword\nwork\nworker\nworld\nworry\nwould\nwrite\nwriter\nwrong\nyard\nyeah\nyear\nyes\nyet\nyou\nyoung\nyour\nyourself");
        String[] words =  text.split("\n");
        return words;
    }


}
